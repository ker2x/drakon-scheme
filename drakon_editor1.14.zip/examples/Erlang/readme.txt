DRAKON-Erlang demo.
To run the demo:
1. cd to this directory.
2. Start Erlang interpreter:
	> erl
3. Compile erldemo.erl:
	1> c(erldemo).
4. Run the demo:
	2> erldemo:main().